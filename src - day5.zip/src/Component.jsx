export function Comp1(){ 
    return(
        <>
        <div>
            <h1>Component1</h1>
        </div>
        </>
    );
}


export function Comp2(){ 
    return(
        <>
        <div>
            <h1>Component2</h1>
        </div>
        </>
    );
}


export function Comp3(){ 
    return(
        <>
        <div>
            <h1>Component3</h1>
        </div>
        </>
    );
}


export function Comp4(){ 
    return(
        <>
        <div>
            <h1>Component4</h1>
        </div>
        </>
    );
}


export function Comp5(){ 
    return(
        <>
        <div>
            <h1>Component5</h1>
        </div>
        </>
    );
}
//export  {Comp1,Comp2,Comp3,Comp4,Comp5};

//export default Component1 - for single export

//export { Component1, Component2, Component3, Component4, Component5 } // uncommented to export all components as named exports
