import { createContext } from "react";

const mycontext = createContext();
export default mycontext ;