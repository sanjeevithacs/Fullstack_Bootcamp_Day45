//DAY-5
//Static Route


import React from 'react'

function Contact() {
  return (
    <div>Contact</div>
  )
}

export default Contact